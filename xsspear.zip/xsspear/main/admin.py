from django.contrib import admin
from .models import List, Item

# Register your models here.
admin.site.register(List)
admin.site.register(Item)